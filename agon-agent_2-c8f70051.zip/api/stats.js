import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const [ordersRes, productsRes, vouchersRes, queueRes, transactionsRes] = await Promise.all([
      supabase.from('orders').select('status, final_amount, created_at'),
      supabase.from('products').select('id', { count: 'exact' }),
      supabase.from('vouchers').select('id, used_count'),
      supabase.from('delivery_queue').select('status'),
      supabase.from('transactions').select('status, amount')
    ]);

    const orders = ordersRes.data || [];
    const totalRevenue = orders.filter(o => o.status === 'paid' || o.status === 'delivered').reduce((s, o) => s + (o.final_amount || 0), 0);
    const totalOrders = orders.length;
    const pendingOrders = orders.filter(o => o.status === 'pending').length;
    const paidOrders = orders.filter(o => o.status === 'paid' || o.status === 'delivered').length;
    const deliveredOrders = orders.filter(o => o.status === 'delivered').length;

    const today = new Date().toISOString().split('T')[0];
    const todayOrders = orders.filter(o => o.created_at && o.created_at.startsWith(today));
    const todayRevenue = todayOrders.filter(o => o.status === 'paid' || o.status === 'delivered').reduce((s, o) => s + (o.final_amount || 0), 0);

    const queue = queueRes.data || [];
    const pendingDelivery = queue.filter(q => q.status === 'queued').length;
    const deliveredCount = queue.filter(q => q.status === 'delivered').length;
    const failedDelivery = queue.filter(q => q.status === 'failed').length;

    const vouchers = vouchersRes.data || [];
    const totalVoucherUses = vouchers.reduce((s, v) => s + (v.used_count || 0), 0);

    // Revenue by day (last 7 days)
    const revenueByDay = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dayStr = d.toISOString().split('T')[0];
      const dayOrders = orders.filter(o => o.created_at && o.created_at.startsWith(dayStr));
      const dayRev = dayOrders.filter(o => o.status === 'paid' || o.status === 'delivered').reduce((s, o) => s + (o.final_amount || 0), 0);
      revenueByDay.push({ date: dayStr, revenue: dayRev, orders: dayOrders.length });
    }

    res.status(200).json({
      totalRevenue,
      totalOrders,
      pendingOrders,
      paidOrders,
      deliveredOrders,
      todayRevenue,
      todayOrders: todayOrders.length,
      totalProducts: productsRes.count || 0,
      pendingDelivery,
      deliveredCount,
      failedDelivery,
      totalVoucherUses,
      revenueByDay
    });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
