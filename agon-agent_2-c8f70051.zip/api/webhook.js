import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const payload = req.body;
    const status = payload.status || payload.transaction_status;
    const orderId = payload.order_id || payload.external_id;
    const gatewayRef = payload.transaction_id || payload.id;

    console.log('[WEBHOOK] Received:', JSON.stringify(payload));

    // Find the order
    let orderQuery = supabase.from('orders').select('*');
    if (orderId) {
      orderQuery = orderQuery.eq('invoice_number', orderId);
    } else if (payload.order_db_id) {
      orderQuery = orderQuery.eq('id', payload.order_db_id);
    } else {
      return res.status(400).json({ error: 'No order identifier' });
    }

    const { data: orders, error: findErr } = await orderQuery;
    if (findErr) throw findErr;
    if (!orders || orders.length === 0) {
      return res.status(404).json({ error: 'Order not found' });
    }

    const order = orders[0];

    // Update transaction
    await supabase.from('transactions')
      .update({
        status: status === 'PAID' || status === 'paid' || status === 'settlement' ? 'paid' : 'failed',
        gateway_ref: gatewayRef,
        raw_payload: payload
      })
      .eq('order_id', order.id);

    if (status === 'PAID' || status === 'paid' || status === 'settlement') {
      // Mark order as paid
      await supabase.from('orders')
        .update({ status: 'paid', paid_at: new Date().toISOString() })
        .eq('id', order.id);

      // Process delivery queue
      const { data: queueItems } = await supabase
        .from('delivery_queue')
        .select('*')
        .eq('order_id', order.id)
        .eq('status', 'queued');

      if (queueItems && queueItems.length > 0) {
        for (const item of queueItems) {
          try {
            // Simulate RCON command execution
            console.log(`[RCON] Executing: ${item.command}`);

            // Mark as delivered
            await supabase.from('delivery_queue')
              .update({ status: 'delivered', last_attempt: new Date().toISOString(), attempts: (item.attempts || 0) + 1 })
              .eq('id', item.id);

            // Update order item delivery status
            await supabase.from('order_items')
              .update({ delivery_status: 'delivered', delivered_at: new Date().toISOString() })
              .eq('id', item.order_item_id);
          } catch (rconErr) {
            console.error('[RCON] Failed:', rconErr);
            await supabase.from('delivery_queue')
              .update({ status: 'failed', last_attempt: new Date().toISOString(), attempts: (item.attempts || 0) + 1 })
              .eq('id', item.id);
          }
        }
      }

      // Mark order as delivered if all items delivered
      const { data: remainingItems } = await supabase
        .from('order_items')
        .select('id')
        .eq('order_id', order.id)
        .neq('delivery_status', 'delivered');

      if (!remainingItems || remainingItems.length === 0) {
        await supabase.from('orders')
          .update({ status: 'delivered' })
          .eq('id', order.id);
      }

      console.log(`[WEBHOOK] Order ${order.invoice_number} processed successfully`);
    } else if (status === 'EXPIRED' || status === 'expired' || status === 'cancel') {
      await supabase.from('orders')
        .update({ status: 'expired' })
        .eq('id', order.id);
    }

    res.status(200).json({ ok: true, message: 'Webhook processed' });
  } catch (err) {
    console.error('[WEBHOOK] Error:', err);
    res.status(500).json({ error: err.message });
  }
}
