import supabase from './_supabase.js';

function generateInvoice() {
  const ts = Date.now().toString(36).toUpperCase();
  const rand = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `INV-${ts}-${rand}`;
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { user_id, status, id } = req.query;
      let query = supabase.from('orders').select('*, order_items(*, products(name, category))').order('created_at', { ascending: false });
      if (user_id) query = query.eq('user_id', user_id);
      if (status) query = query.eq('status', status);
      if (id) query = query.eq('id', id);
      const { data, error } = await query;
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'POST') {
      const { user_id, minecraft_username, items, voucher_code, payment_method } = req.body;

      // Calculate total
      const productIds = items.map(i => i.product_id);
      const { data: products, error: prodErr } = await supabase
        .from('products').select('*').in('id', productIds);
      if (prodErr) throw prodErr;

      let total = 0;
      const orderItemsData = [];
      for (const item of items) {
        const prod = products.find(p => p.id === item.product_id);
        if (!prod) return res.status(400).json({ error: `Product ${item.product_id} not found` });
        if (prod.stock !== null && prod.stock < item.quantity) return res.status(400).json({ error: `${prod.name} out of stock` });
        const subtotal = prod.price * item.quantity;
        total += subtotal;
        orderItemsData.push({
          product_id: prod.id,
          quantity: item.quantity,
          price: prod.price,
          command: prod.command,
          delivery_status: 'pending'
        });
      }

      // Apply voucher
      let discount = 0;
      if (voucher_code) {
        const { data: voucher } = await supabase
          .from('vouchers')
          .select('*')
          .eq('code', voucher_code)
          .eq('active', true)
          .single();
        if (voucher) {
          const now = new Date();
          const expires = new Date(voucher.expires_at);
          if (expires > now && voucher.used_count < voucher.max_uses) {
            discount = Math.round(total * voucher.discount_percent / 100);
            await supabase.from('vouchers').update({ used_count: voucher.used_count + 1 }).eq('id', voucher.id);
          }
        }
      }

      const finalAmount = total - discount;
      const invoiceNumber = generateInvoice();

      // Create order
      const { data: order, error: orderErr } = await supabase
        .from('orders')
        .insert({
          user_id,
          minecraft_username,
          invoice_number: invoiceNumber,
          total_amount: total,
          discount_amount: discount,
          final_amount: finalAmount,
          status: 'pending',
          payment_method: payment_method || 'qris',
          voucher_code
        })
        .select()
        .single();
      if (orderErr) throw orderErr;

      // Create order items
      const orderItemsWithOrderId = orderItemsData.map(oi => ({ ...oi, order_id: order.id }));
      const { data: orderItems, error: oiErr } = await supabase
        .from('order_items')
        .insert(orderItemsWithOrderId)
        .select();
      if (oiErr) throw oiErr;

      // Create delivery queue entries
      const deliveryEntries = orderItems.map(oi => ({
        order_id: order.id,
        order_item_id: oi.id,
        command: oi.command ? oi.command.replace('{username}', minecraft_username) : null,
        status: 'queued'
      }));
      if (deliveryEntries.length > 0 && deliveryEntries[0].command) {
        await supabase.from('delivery_queue').insert(deliveryEntries);
      }

      // Create transaction record
      await supabase.from('transactions').insert({
        order_id: order.id,
        gateway: payment_method || 'qris',
        amount: finalAmount,
        status: 'pending'
      });

      // Update stock
      for (const item of items) {
        const prod = products.find(p => p.id === item.product_id);
        if (prod.stock !== null) {
          await supabase.from('products').update({ stock: prod.stock - item.quantity }).eq('id', prod.id);
        }
      }

      return res.status(201).json({ ...order, order_items: orderItems });
    }
    if (req.method === 'PUT') {
      const { id, status } = req.body;
      const updates = { status };
      if (status === 'paid') updates.paid_at = new Date().toISOString();
      const { data, error } = await supabase
        .from('orders')
        .update(updates)
        .eq('id', id)
        .select()
        .single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
