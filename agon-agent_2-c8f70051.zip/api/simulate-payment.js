import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { order_id } = req.body;
    if (!order_id) return res.status(400).json({ error: 'order_id required' });

    const { data: order } = await supabase.from('orders').select('*').eq('id', order_id).single();
    if (!order) return res.status(404).json({ error: 'Order not found' });
    if (order.status !== 'pending') return res.status(400).json({ error: 'Order is not pending' });

    // Simulate webhook call
    const webhookPayload = {
      status: 'PAID',
      order_id: order.invoice_number,
      transaction_id: `SIM-${Date.now()}`,
      payment_type: order.payment_method,
      gross_amount: order.final_amount,
      transaction_time: new Date().toISOString()
    };

    // Process directly
    await supabase.from('transactions')
      .update({
        status: 'paid',
        gateway_ref: webhookPayload.transaction_id,
        raw_payload: webhookPayload
      })
      .eq('order_id', order.id);

    await supabase.from('orders')
      .update({ status: 'paid', paid_at: new Date().toISOString() })
      .eq('id', order.id);

    // Process delivery queue
    const { data: queueItems } = await supabase
      .from('delivery_queue')
      .select('*')
      .eq('order_id', order.id)
      .eq('status', 'queued');

    if (queueItems && queueItems.length > 0) {
      for (const item of queueItems) {
        console.log(`[RCON] Executing: ${item.command}`);
        await supabase.from('delivery_queue')
          .update({ status: 'delivered', last_attempt: new Date().toISOString(), attempts: (item.attempts || 0) + 1 })
          .eq('id', item.id);
        await supabase.from('order_items')
          .update({ delivery_status: 'delivered', delivered_at: new Date().toISOString() })
          .eq('id', item.order_item_id);
      }
    }

    // Check if all items delivered
    const { data: remainingItems } = await supabase
      .from('order_items')
      .select('id')
      .eq('order_id', order.id)
      .neq('delivery_status', 'delivered');

    if (!remainingItems || remainingItems.length === 0) {
      await supabase.from('orders').update({ status: 'delivered' }).eq('id', order.id);
    }

    res.status(200).json({ ok: true, message: 'Payment simulated and auto-delivery processed', invoice: order.invoice_number });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
