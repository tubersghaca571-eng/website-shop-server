import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { user_id } = req.query;
      if (!user_id) return res.status(400).json({ error: 'user_id required' });
      const { data, error } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('user_id', user_id)
        .maybeSingle();
      if (error) throw error;
      return res.status(200).json(data || { user_id, minecraft_username: '', balance: 0 });
    }
    if (req.method === 'POST' || req.method === 'PUT') {
      const { user_id, minecraft_username, email } = req.body;
      const { data: existing } = await supabase
        .from('user_profiles')
        .select('id')
        .eq('user_id', user_id)
        .maybeSingle();

      if (existing) {
        const { data, error } = await supabase
          .from('user_profiles')
          .update({ minecraft_username })
          .eq('user_id', user_id)
          .select()
          .single();
        if (error) throw error;
        return res.status(200).json(data);
      } else {
        const { data, error } = await supabase
          .from('user_profiles')
          .insert({ user_id, minecraft_username, email, balance: 0 })
          .select()
          .single();
        if (error) throw error;
        return res.status(201).json(data);
      }
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
