import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, PUT, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { status } = req.query;
      let query = supabase.from('delivery_queue').select('*, orders(invoice_number, minecraft_username)').order('created_at', { ascending: false });
      if (status) query = query.eq('status', status);
      const { data, error } = await query;
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'PUT') {
      const { id, status } = req.body;
      const { data, error } = await supabase
        .from('delivery_queue')
        .update({ status, last_attempt: new Date().toISOString(), attempts: 1 })
        .eq('id', id)
        .select()
        .single();
      if (error) throw error;

      if (status === 'delivered') {
        await supabase.from('order_items')
          .update({ delivery_status: 'delivered', delivered_at: new Date().toISOString() })
          .eq('id', data.order_item_id);
      }

      return res.status(200).json(data);
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
