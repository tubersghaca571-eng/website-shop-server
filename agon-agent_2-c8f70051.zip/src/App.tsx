import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { useState, useEffect, createContext } from 'react';
import supabase from './lib/supabase';
import { handleGoogleRedirect } from './lib/googleAuth';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Shop from './pages/Shop';
import Cart from './pages/Cart';
import Login from './pages/Login';
import Orders from './pages/Orders';
import Admin from './pages/Admin';
import CheckoutSuccess from './pages/CheckoutSuccess';

handleGoogleRedirect();

export const AuthContext = createContext<any>(null);
export const CartContext = createContext<any>(null);

export default function App() {
  const [user, setUser] = useState<any>(null);
  const [profile, setProfile] = useState<any>(null);
  const [cart, setCart] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }: any) => {
      setUser(session?.user ?? null);
      setLoading(false);
    });
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event: any, session: any) => {
      setUser(session?.user ?? null);
    });
    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (user) {
      fetch(`/api/profile?user_id=${user.id}`)
        .then(r => r.json())
        .then(data => {
          setProfile(data);
          if (!data.id && user.email) {
            fetch('/api/profile', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ user_id: user.id, email: user.email, minecraft_username: '' })
            }).then(() => fetch(`/api/profile?user_id=${user.id}`).then(r => r.json()).then(setProfile));
          }
        });
    } else {
      setProfile(null);
    }
  }, [user]);

  useEffect(() => {
    const saved = localStorage.getItem('mcshop_cart');
    if (saved) setCart(JSON.parse(saved));
  }, []);

  useEffect(() => {
    localStorage.setItem('mcshop_cart', JSON.stringify(cart));
  }, [cart]);

  const addToCart = (product: any) => {
    setCart(prev => {
      const existing = prev.find(c => c.id === product.id);
      if (existing) return prev.map(c => c.id === product.id ? { ...c, qty: c.qty + 1 } : c);
      return [...prev, { ...product, qty: 1 }];
    });
  };

  const removeFromCart = (productId: number) => setCart(prev => prev.filter(c => c.id !== productId));
  const updateQty = (productId: number, qty: number) => {
    if (qty <= 0) return removeFromCart(productId);
    setCart(prev => prev.map(c => c.id === productId ? { ...c, qty } : c));
  };
  const clearCart = () => setCart([]);

  if (loading) return (
    <div className="min-h-screen bg-gray-950 flex items-center justify-center">
      <div className="flex flex-col items-center gap-4">
        <div className="w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
        <p className="text-emerald-400 font-mono">Loading...</p>
      </div>
    </div>
  );

  return (
    <AuthContext.Provider value={{ user, profile, setProfile }}>
      <CartContext.Provider value={{ cart, addToCart, removeFromCart, updateQty, clearCart }}>
        <BrowserRouter>
          <div className="min-h-screen bg-gray-950 text-white">
            <Navbar />
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/shop" element={<Shop />} />
              <Route path="/cart" element={<Cart />} />
              <Route path="/login" element={<Login />} />
              <Route path="/orders" element={<Orders />} />
              <Route path="/admin" element={<Admin />} />
              <Route path="/checkout-success" element={<CheckoutSuccess />} />
            </Routes>
          </div>
        </BrowserRouter>
      </CartContext.Provider>
    </AuthContext.Provider>
  );
}
