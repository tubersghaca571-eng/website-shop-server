import { useSearchParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CheckCircle, ArrowRight, Zap } from 'lucide-react';
import { useState, useEffect } from 'react';

export default function CheckoutSuccess() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const orderId = params.get('order_id');
  const invoice = params.get('invoice');
  const [order, setOrder] = useState<any>(null);
  const [simulating, setSimulating] = useState(false);

  useEffect(() => {
    if (orderId) {
      fetch(`/api/orders?id=${orderId}`).then(r => r.json()).then(data => {
        if (data && data.length > 0) setOrder(data[0]);
      });
    }
  }, [orderId]);

  const simulatePayment = async () => {
    if (!orderId) return;
    setSimulating(true);
    try {
      const res = await fetch('/api/simulate-payment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ order_id: parseInt(orderId) })
      });
      const data = await res.json();
      if (res.ok) {
        const updated = await fetch(`/api/orders?id=${orderId}`).then(r => r.json());
        if (updated && updated.length > 0) setOrder(updated[0]);
      }
    } catch {} finally {
      setSimulating(false);
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-md w-full text-center"
      >
        <div className="w-20 h-20 bg-emerald-500/10 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle className="text-emerald-400" size={40} />
        </div>
        <h1 className="text-2xl font-bold mb-2">Order Dibuat!</h1>
        <p className="text-gray-400 mb-4">Invoice: <span className="font-mono text-white">{invoice}</span></p>

        {order && (
          <div className="bg-gray-900 border border-gray-800 rounded-xl p-4 mb-6 text-left">
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-400">Status</span>
                <span className={order.status === 'pending' ? 'text-yellow-400' : order.status === 'paid' ? 'text-blue-400' : 'text-emerald-400'}>
                  {order.status === 'pending' ? '⏳ Menunggu Pembayaran' : order.status === 'paid' ? '💳 Dibayar' : '✅ Terkirim'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Total</span>
                <span className="text-emerald-400 font-bold">Rp {(order.final_amount || 0).toLocaleString('id-ID')}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">MC Username</span>
                <span className="text-white">{order.minecraft_username}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Payment</span>
                <span className="text-white capitalize">{order.payment_method}</span>
              </div>
            </div>
          </div>
        )}

        {order?.status === 'pending' && (
          <button
            onClick={simulatePayment}
            disabled={simulating}
            className="w-full py-3 mb-4 bg-emerald-500 hover:bg-emerald-400 text-gray-950 font-bold rounded-xl transition disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {simulating ? (
              <><div className="w-4 h-4 border-2 border-gray-950 border-t-transparent rounded-full animate-spin" /> Processing...</>
            ) : (
              <><Zap size={18} /> Simulasi Pembayaran (Demo)</>
            )}
          </button>
        )}

        {order?.status === 'delivered' && (
          <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-4 mb-4">
            <p className="text-emerald-400 font-medium">✅ Produk sudah otomatis dikirim ke server Minecraft!</p>
            <p className="text-emerald-400/60 text-sm mt-1">Auto delivery via webhook + RCON</p>
          </div>
        )}

        <div className="flex gap-3">
          <button onClick={() => navigate('/orders')} className="flex-1 py-3 bg-gray-800 hover:bg-gray-700 text-white font-semibold rounded-xl transition">
            Lihat Pesanan
          </button>
          <button onClick={() => navigate('/shop')} className="flex-1 py-3 bg-emerald-500 hover:bg-emerald-400 text-gray-950 font-semibold rounded-xl transition flex items-center justify-center gap-2">
            Belanja Lagi <ArrowRight size={16} />
          </button>
        </div>
      </motion.div>
    </div>
  );
}
