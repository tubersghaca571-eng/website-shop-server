import { useContext, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { CartContext } from '../App';
import { motion } from 'framer-motion';
import { ArrowRight, Zap, Shield, Clock, ShoppingCart, Star, ChevronRight } from 'lucide-react';

export default function Home() {
  const { addToCart } = useContext(CartContext);
  const [featured, setFeatured] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/products?active=true')
      .then(r => r.json())
      .then(data => {
        setFeatured((data || []).slice(0, 4));
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const categoryColors: Record<string, string> = {
    rank: 'from-amber-500 to-orange-600',
    item: 'from-blue-500 to-cyan-600',
    access: 'from-purple-500 to-pink-600',
    whitelist: 'from-emerald-500 to-teal-600',
    balance: 'from-yellow-500 to-amber-600',
  };

  const categoryIcons: Record<string, string> = {
    rank: '👑',
    item: '💎',
    access: '🔐',
    whitelist: '✅',
    balance: '🪙',
  };

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-emerald-900/30 via-gray-950 to-gray-950" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-emerald-500/10 via-transparent to-transparent" />
        <div className="absolute top-20 left-10 w-72 h-72 bg-emerald-500/5 rounded-full blur-3xl" />
        <div className="absolute bottom-10 right-10 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl" />

        <div className="relative max-w-7xl mx-auto px-4 py-24 sm:py-32">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-3xl mx-auto"
          >
            <div className="inline-flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/20 rounded-full px-4 py-1.5 mb-6">
              <Zap size={14} className="text-emerald-400" />
              <span className="text-emerald-400 text-sm font-medium">Auto Delivery 24/7 — No Admin Needed</span>
            </div>
            <h1 className="text-4xl sm:text-6xl font-black mb-6 leading-tight">
              Minecraft Server
              <br />
              <span className="bg-gradient-to-r from-emerald-400 via-cyan-400 to-emerald-400 bg-clip-text text-transparent">Shop & Auto Delivery</span>
            </h1>
            <p className="text-gray-400 text-lg sm:text-xl mb-8 max-w-2xl mx-auto">
              Bayar → langsung dikasih. Gak perlu nunggu admin bangun tidur.
              Rank, item, whitelist — semua otomatis via webhook payment gateway.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to="/shop" className="px-8 py-3.5 bg-emerald-500 hover:bg-emerald-400 text-gray-950 font-bold rounded-xl text-lg transition flex items-center gap-2 group">
                Belanja Sekarang <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link to="/login" className="px-8 py-3.5 bg-gray-800 hover:bg-gray-700 text-white font-semibold rounded-xl text-lg transition border border-gray-700">
                Login / Daftar
              </Link>
            </div>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="grid grid-cols-3 gap-4 max-w-lg mx-auto mt-16"
          >
            {[
              { label: 'Auto Delivery', value: '24/7' },
              { label: 'Payment', value: 'QRIS' },
              { label: 'Instant', value: '<1min' },
            ].map(s => (
              <div key={s.label} className="text-center">
                <div className="text-2xl sm:text-3xl font-black text-emerald-400">{s.value}</div>
                <div className="text-xs sm:text-sm text-gray-500">{s.label}</div>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-20 bg-gray-900/50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-3">Cara Kerjanya</h2>
            <p className="text-gray-400">Simpel. Bayar → Auto dikasih. Gitu doang.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { step: '1', icon: '🛒', title: 'Pilih Produk', desc: 'Pilih rank, item, atau apapun yang lu mau', color: 'from-emerald-500 to-teal-600' },
              { step: '2', icon: '💳', title: 'Bayar', desc: 'Bayar pake QRIS, e-wallet, atau transfer', color: 'from-blue-500 to-cyan-600' },
              { step: '3', icon: '🔔', title: 'Webhook Notif', desc: 'Payment gateway ngasih notif ke server kita', color: 'from-purple-500 to-pink-600' },
              { step: '4', icon: '⚡', title: 'Auto Delivery', desc: 'Server langsung execute command ke MC server', color: 'from-amber-500 to-orange-600' },
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * i }}
                className="relative"
              >
                <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6 h-full hover:border-gray-700 transition">
                  <div className={`w-12 h-12 bg-gradient-to-br ${item.color} rounded-xl flex items-center justify-center text-xl mb-4 shadow-lg`}>{item.icon}</div>
                  <div className="text-xs font-bold text-emerald-400 mb-1">STEP {item.step}</div>
                  <h3 className="font-bold text-lg mb-2">{item.title}</h3>
                  <p className="text-gray-400 text-sm">{item.desc}</p>
                </div>
                {i < 3 && (
                  <ChevronRight className="hidden lg:block absolute top-1/2 -right-3 text-gray-700" size={20} />
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-3xl font-bold mb-1">Produk Populer</h2>
              <p className="text-gray-400">Rank dan item terlaris</p>
            </div>
            <Link to="/shop" className="text-emerald-400 hover:text-emerald-300 text-sm font-medium flex items-center gap-1 group">
              Lihat Semua <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[1,2,3,4].map(i => (
                <div key={i} className="bg-gray-900 border border-gray-800 rounded-2xl overflow-hidden animate-pulse">
                  <div className="h-32 bg-gray-800" />
                  <div className="p-4 space-y-3">
                    <div className="h-5 bg-gray-800 rounded w-3/4" />
                    <div className="h-4 bg-gray-800 rounded w-full" />
                    <div className="h-8 bg-gray-800 rounded w-1/2" />
                  </div>
                </div>
              ))}
            </div>
          ) : featured.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {featured.map((p: any) => (
                <motion.div
                  key={p.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-gray-900 border border-gray-800 rounded-2xl overflow-hidden group hover:border-emerald-500/50 transition-all"
                >
                  <div className={`h-28 bg-gradient-to-br ${categoryColors[p.category] || 'from-gray-500 to-gray-600'} flex items-center justify-center relative`}>
                    <span className="text-4xl">{categoryIcons[p.category] || '📦'}</span>
                  </div>
                  <div className="p-4">
                    <h3 className="font-bold mb-1">{p.name}</h3>
                    <p className="text-gray-400 text-sm mb-3 line-clamp-2">{p.description}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-xl font-bold text-emerald-400">Rp {(p.price || 0).toLocaleString('id-ID')}</span>
                      <button onClick={() => addToCart(p)} className="p-2 bg-emerald-500 hover:bg-emerald-400 text-gray-950 rounded-lg transition">
                        <ShoppingCart size={16} />
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 text-gray-500">
              <Package className="mx-auto mb-3" size={40} />
              <p>Belum ada produk. Admin belum nambahin.</p>
            </div>
          )}

          {/* Tech Stack */}
          <div className="mt-20 text-center">
            <h2 className="text-2xl font-bold mb-6">Built With</h2>
            <div className="flex flex-wrap items-center justify-center gap-3">
              {['React', 'Node.js', 'Supabase', 'Tailwind CSS', 'Webhook', 'RCON', 'QRIS'].map(tech => (
                <span key={tech} className="px-4 py-2 bg-gray-800 border border-gray-700 rounded-full text-sm text-gray-300 font-medium">{tech}</span>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-gray-800 py-8">
        <div className="max-w-7xl mx-auto px-4 text-center text-gray-500 text-sm">
          <p>MCShop — Payment Gateway + Auto Delivery System</p>
          <p className="mt-1">Teknologi diciptain karena admin suka tidur. Tragis tapi efisien. 😴</p>
        </div>
      </footer>
    </div>
  );
}

function Package(props: any) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width={props.size || 24} height={props.size || 24} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m7.5 4.27 9 5.15"/><path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><path d="m3.3 7 8.7 5 8.7-5"/><path d="M12 22V12"/></svg>
  );
}
