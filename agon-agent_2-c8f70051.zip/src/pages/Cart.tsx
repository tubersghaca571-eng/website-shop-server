import { useContext, useState } from 'react';
import { AuthContext, CartContext } from '../App';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Trash2, Plus, Minus, ShoppingBag, Tag, CreditCard, ChevronRight } from 'lucide-react';

export default function Cart() {
  const { user, profile } = useContext(AuthContext);
  const { cart, removeFromCart, updateQty, clearCart } = useContext(CartContext);
  const navigate = useNavigate();
  const [voucherCode, setVoucherCode] = useState('');
  const [discount, setDiscount] = useState(0);
  const [voucherMsg, setVoucherMsg] = useState('');
  const [minecraftUsername, setMinecraftUsername] = useState(profile?.minecraft_username || '');
  const [paymentMethod, setPaymentMethod] = useState('qris');
  const [checkingOut, setCheckingOut] = useState(false);

  const total = cart.reduce((s: number, c: any) => s + c.price * c.qty, 0);
  const finalAmount = total - discount;

  const applyVoucher = async () => {
    if (!voucherCode) return;
    try {
      const res = await fetch(`/api/vouchers?code=${voucherCode.toUpperCase()}&active=true`);
      const data = await res.json();
      if (data && data.length > 0) {
        const v = data[0];
        const now = new Date();
        const expires = new Date(v.expires_at);
        if (expires > now && v.used_count < v.max_uses) {
          const disc = Math.round(total * v.discount_percent / 100);
          setDiscount(disc);
          setVoucherMsg(`✅ Voucher applied! ${v.discount_percent}% off = Rp ${disc.toLocaleString('id-ID')}`);
        } else {
          setVoucherMsg('❌ Voucher expired atau sudah habis');
        }
      } else {
        setVoucherMsg('❌ Voucher tidak valid');
      }
    } catch {
      setVoucherMsg('❌ Gagal cek voucher');
    }
  };

  const handleCheckout = async () => {
    if (!user) { navigate('/login'); return; }
    if (!minecraftUsername.trim()) { alert('Masukkan username Minecraft!'); return; }
    if (cart.length === 0) return;

    setCheckingOut(true);
    try {
      const items = cart.map((c: any) => ({ product_id: c.id, quantity: c.qty }));
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: user.id,
          minecraft_username: minecraftUsername,
          items,
          voucher_code: voucherCode || undefined,
          payment_method: paymentMethod
        })
      });
      const data = await res.json();
      if (res.ok) {
        // Save minecraft username to profile
        await fetch('/api/profile', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ user_id: user.id, minecraft_username: minecraftUsername })
        });
        clearCart();
        navigate(`/checkout-success?order_id=${data.id}&invoice=${data.invoice_number}`);
      } else {
        alert(data.error || 'Checkout gagal');
      }
    } catch {
      alert('Gagal checkout. Coba lagi.');
    } finally {
      setCheckingOut(false);
    }
  };

  if (cart.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}>
          <ShoppingBag className="mx-auto mb-4 text-gray-600" size={64} />
          <h2 className="text-2xl font-bold mb-2">Keranjang Kosong</h2>
          <p className="text-gray-400 mb-6">Belum ada produk di keranjang. Yuk belanja!</p>
          <Link to="/shop" className="inline-flex items-center gap-2 px-6 py-3 bg-emerald-500 hover:bg-emerald-400 text-gray-950 font-semibold rounded-xl transition">
            Belanja Sekarang <ChevronRight size={18} />
          </Link>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-3xl font-bold mb-6">Keranjang Belanja</h1>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {cart.map((item: any) => (
              <div key={item.id} className="bg-gray-900 border border-gray-800 rounded-xl p-4 flex items-center gap-4">
                <div className="w-16 h-16 bg-gray-800 rounded-lg flex items-center justify-center text-2xl shrink-0">
                  {{ rank: '👑', item: '💎', access: '🔐', whitelist: '✅', balance: '🪙' }[item.category as string] || '📦'}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold truncate">{item.name}</h3>
                  <p className="text-emerald-400 text-sm font-medium">Rp {(item.price || 0).toLocaleString('id-ID')}</p>
                </div>
                <div className="flex items-center gap-2">
                  <button onClick={() => updateQty(item.id, item.qty - 1)} className="p-1.5 bg-gray-800 rounded-lg hover:bg-gray-700 transition">
                    <Minus size={14} />
                  </button>
                  <span className="w-8 text-center font-medium">{item.qty}</span>
                  <button onClick={() => updateQty(item.id, item.qty + 1)} className="p-1.5 bg-gray-800 rounded-lg hover:bg-gray-700 transition">
                    <Plus size={14} />
                  </button>
                </div>
                <div className="text-right w-28">
                  <p className="font-bold text-white">Rp {(item.price * item.qty).toLocaleString('id-ID')}</p>
                </div>
                <button onClick={() => removeFromCart(item.id)} className="p-2 text-gray-500 hover:text-red-400 transition">
                  <Trash2 size={18} />
                </button>
              </div>
            ))}
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 sticky top-24">
              <h3 className="font-bold text-lg mb-4">Ringkasan Order</h3>

              {/* Minecraft Username */}
              <div className="mb-4">
                <label className="text-sm text-gray-400 mb-1.5 block">Username Minecraft</label>
                <input
                  type="text"
                  value={minecraftUsername}
                  onChange={e => setMinecraftUsername(e.target.value)}
                  placeholder="Contoh: Steve"
                  className="w-full px-3 py-2.5 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-emerald-500 transition"
                />
              </div>

              {/* Payment Method */}
              <div className="mb-4">
                <label className="text-sm text-gray-400 mb-1.5 block">Metode Pembayaran</label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { key: 'qris', label: 'QRIS', icon: '📱' },
                    { key: 'ewallet', label: 'E-Wallet', icon: '💳' },
                    { key: 'bank', label: 'Transfer Bank', icon: '🏦' },
                    { key: 'convenience', label: 'Indomaret', icon: '🏪' },
                  ].map(m => (
                    <button
                      key={m.key}
                      onClick={() => setPaymentMethod(m.key)}
                      className={`px-3 py-2 rounded-lg text-xs font-medium flex items-center gap-1.5 transition ${
                        paymentMethod === m.key
                          ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400 border'
                          : 'bg-gray-800 border border-gray-700 text-gray-400 hover:border-gray-600'
                      }`}
                    >
                      <span>{m.icon}</span> {m.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Voucher */}
              <div className="mb-4">
                <label className="text-sm text-gray-400 mb-1.5 block">Kode Voucher</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={voucherCode}
                    onChange={e => setVoucherCode(e.target.value.toUpperCase())}
                    placeholder="Masukkan kode"
                    className="flex-1 px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-emerald-500 transition text-sm"
                  />
                  <button onClick={applyVoucher} className="px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-emerald-400 hover:bg-gray-700 transition">
                    <Tag size={16} />
                  </button>
                </div>
                {voucherMsg && <p className="text-xs mt-1.5 text-gray-400">{voucherMsg}</p>}
              </div>

              {/* Totals */}
              <div className="space-y-2 py-4 border-t border-gray-800">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Subtotal</span>
                  <span>Rp {total.toLocaleString('id-ID')}</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-sm">
                    <span className="text-emerald-400">Diskon</span>
                    <span className="text-emerald-400">-Rp {discount.toLocaleString('id-ID')}</span>
                  </div>
                )}
                <div className="flex justify-between font-bold text-lg pt-2 border-t border-gray-800">
                  <span>Total</span>
                  <span className="text-emerald-400">Rp {finalAmount.toLocaleString('id-ID')}</span>
                </div>
              </div>

              <button
                onClick={handleCheckout}
                disabled={checkingOut}
                className="w-full py-3 bg-emerald-500 hover:bg-emerald-400 text-gray-950 font-bold rounded-xl transition disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {checkingOut ? (
                  <><div className="w-4 h-4 border-2 border-gray-950 border-t-transparent rounded-full animate-spin" /> Processing...</>
                ) : (
                  <><CreditCard size={18} /> Checkout</>
                )}
              </button>

              {!user && (
                <p className="text-xs text-gray-500 text-center mt-2">Login dulu sebelum checkout</p>
              )}
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
