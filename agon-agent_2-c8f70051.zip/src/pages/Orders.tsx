import { useContext, useEffect, useState } from 'react';
import { AuthContext } from '../App';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Package, Clock, CheckCircle, XCircle, Zap, ExternalLink } from 'lucide-react';

const statusConfig: Record<string, { color: string; icon: any; label: string }> = {
  pending: { color: 'text-yellow-400 bg-yellow-400/10 border-yellow-400/20', icon: Clock, label: 'Menunggu Pembayaran' },
  paid: { color: 'text-blue-400 bg-blue-400/10 border-blue-400/20', icon: CheckCircle, label: 'Dibayar' },
  delivered: { color: 'text-emerald-400 bg-emerald-400/10 border-emerald-400/20', icon: CheckCircle, label: 'Terkirim' },
  expired: { color: 'text-red-400 bg-red-400/10 border-red-400/20', icon: XCircle, label: 'Expired' },
  cancelled: { color: 'text-gray-400 bg-gray-400/10 border-gray-400/20', icon: XCircle, label: 'Dibatalkan' },
};

export default function Orders() {
  const { user } = useContext(AuthContext);
  const navigate = useNavigate();
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [simulating, setSimulating] = useState<number | null>(null);

  useEffect(() => {
    if (!user) { navigate('/login'); return; }
    fetchOrders();
  }, [user]);

  const fetchOrders = async () => {
    try {
      const res = await fetch(`/api/orders?user_id=${user.id}`);
      const data = await res.json();
      setOrders(data || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const simulatePayment = async (orderId: number) => {
    setSimulating(orderId);
    try {
      const res = await fetch('/api/simulate-payment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ order_id: orderId })
      });
      const data = await res.json();
      if (res.ok) {
        await fetchOrders();
      } else {
        alert(data.error || 'Simulasi gagal');
      }
    } catch {
      alert('Gagal simulasi payment');
    } finally {
      setSimulating(null);
    }
  };

  if (!user) return null;

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-3xl font-bold mb-2">Pesanan Saya</h1>
        <p className="text-gray-400 mb-6">Riwayat dan status pesanan kamu</p>

        {loading ? (
          <div className="space-y-4">
            {[1,2,3].map(i => (
              <div key={i} className="bg-gray-900 border border-gray-800 rounded-xl p-6 animate-pulse">
                <div className="h-5 bg-gray-800 rounded w-1/4 mb-4" />
                <div className="h-4 bg-gray-800 rounded w-1/2" />
              </div>
            ))}
          </div>
        ) : orders.length > 0 ? (
          <div className="space-y-4">
            {orders.map((order: any) => {
              const status = statusConfig[order.status] || statusConfig.pending;
              const StatusIcon = status.icon;
              return (
                <div key={order.id} className="bg-gray-900 border border-gray-800 rounded-xl p-5 hover:border-gray-700 transition">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-mono text-sm text-gray-400">{order.invoice_number}</span>
                        <span className={`px-2.5 py-1 rounded-full text-xs font-medium border ${status.color} flex items-center gap-1`}>
                          <StatusIcon size={12} /> {status.label}
                        </span>
                      </div>
                      <p className="text-sm text-gray-500">
                        {new Date(order.created_at).toLocaleString('id-ID')} • MC: {order.minecraft_username}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-xl font-bold text-emerald-400">Rp {(order.final_amount || 0).toLocaleString('id-ID')}</p>
                      {order.discount_amount > 0 && (
                        <p className="text-xs text-emerald-400/60">Hemat Rp {order.discount_amount.toLocaleString('id-ID')}</p>
                      )}
                    </div>
                  </div>

                  {/* Order Items */}
                  {order.order_items && (
                    <div className="space-y-2 mb-4">
                      {order.order_items.map((oi: any) => (
                        <div key={oi.id} className="flex items-center justify-between text-sm bg-gray-800/50 rounded-lg px-3 py-2">
                          <div className="flex items-center gap-2">
                            <span>{{ rank: '👑', item: '💎', access: '🔐', whitelist: '✅', balance: '🪙' }[oi.products?.category as string] || '📦'}</span>
                            <span>{oi.products?.name || `Product #${oi.product_id}`}</span>
                            <span className="text-gray-500">x{oi.quantity}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-gray-400">Rp {((oi.price || 0) * (oi.quantity || 1)).toLocaleString('id-ID')}</span>
                            {oi.delivery_status === 'delivered' && (
                              <span className="text-emerald-400 text-xs flex items-center gap-0.5"><CheckCircle size={10} /> Delivered</span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Simulate Payment Button */}
                  {order.status === 'pending' && (
                    <button
                      onClick={() => simulatePayment(order.id)}
                      disabled={simulating === order.id}
                      className="px-4 py-2 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-lg text-sm font-medium hover:bg-emerald-500/30 transition flex items-center gap-1.5 disabled:opacity-50"
                    >
                      {simulating === order.id ? (
                        <><div className="w-3 h-3 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin" /> Processing...</>
                      ) : (
                        <><Zap size={14} /> Simulasi Bayar (Demo)</>
                      )}
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-20">
            <Package className="mx-auto mb-4 text-gray-600" size={64} />
            <h3 className="text-xl font-bold mb-2">Belum ada pesanan</h3>
            <p className="text-gray-400">Yuk belanja dulu!</p>
          </div>
        )}
      </motion.div>
    </div>
  );
}
