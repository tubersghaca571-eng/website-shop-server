import { useContext, useEffect, useState } from 'react';
import { AuthContext } from '../App';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  BarChart3, Package, ShoppingBag, Tag, Truck, Plus, Edit3, Trash2,
  RefreshCw, DollarSign, Users, Clock, CheckCircle, XCircle, Zap, Shield
} from 'lucide-react';

export default function Admin() {
  const { user } = useContext(AuthContext);
  const navigate = useNavigate();
  const [tab, setTab] = useState<'stats' | 'products' | 'orders' | 'delivery' | 'vouchers'>('stats');
  const [stats, setStats] = useState<any>(null);
  const [products, setProducts] = useState<any[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [delivery, setDelivery] = useState<any[]>([]);
  const [vouchers, setVouchers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Product form
  const [showProductForm, setShowProductForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState<any>(null);
  const [pName, setPName] = useState('');
  const [pDesc, setPDesc] = useState('');
  const [pPrice, setPPrice] = useState('');
  const [pCategory, setPCategory] = useState('rank');
  const [pCommand, setPCommand] = useState('');
  const [pStock, setPStock] = useState('');

  // Voucher form
  const [showVoucherForm, setShowVoucherForm] = useState(false);
  const [vCode, setVCode] = useState('');
  const [vDiscount, setVDiscount] = useState('');
  const [vMaxUses, setVMaxUses] = useState('');
  const [vExpires, setVExpires] = useState('');

  useEffect(() => {
    if (!user) { navigate('/login'); return; }
    fetchAll();
  }, [user]);

  const fetchAll = async () => {
    setLoading(true);
    try {
      const [statsRes, prodRes, ordRes, delRes, vouchRes] = await Promise.all([
        fetch('/api/stats').then(r => r.json()),
        fetch('/api/products').then(r => r.json()),
        fetch('/api/orders').then(r => r.json()),
        fetch('/api/delivery').then(r => r.json()),
        fetch('/api/vouchers').then(r => r.json()),
      ]);
      setStats(statsRes);
      setProducts(prodRes || []);
      setOrders(ordRes || []);
      setDelivery(delRes || []);
      setVouchers(vouchRes || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const saveProduct = async () => {
    const payload = {
      name: pName, description: pDesc, price: parseInt(pPrice),
      category: pCategory, command: pCommand, stock: pStock ? parseInt(pStock) : null, active: true
    };
    try {
      if (editingProduct) {
        await fetch('/api/products', {
          method: 'PUT', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: editingProduct.id, ...payload })
        });
      } else {
        await fetch('/api/products', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
      }
      resetProductForm();
      fetchAll();
    } catch { alert('Gagal simpan produk'); }
  };

  const deleteProduct = async (id: number) => {
    if (!confirm('Hapus produk ini?')) return;
    await fetch('/api/products', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) });
    fetchAll();
  };

  const resetProductForm = () => {
    setShowProductForm(false); setEditingProduct(null);
    setPName(''); setPDesc(''); setPPrice(''); setPCategory('rank'); setPCommand(''); setPStock('');
  };

  const editProduct = (p: any) => {
    setEditingProduct(p); setShowProductForm(true);
    setPName(p.name); setPDesc(p.description || ''); setPPrice(p.price.toString());
    setPCategory(p.category); setPCommand(p.command || ''); setPStock(p.stock?.toString() || '');
  };

  const saveVoucher = async () => {
    try {
      await fetch('/api/vouchers', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code: vCode, discount_percent: parseInt(vDiscount),
          max_uses: parseInt(vMaxUses), expires_at: new Date(vExpires).toISOString()
        })
      });
      setShowVoucherForm(false); setVCode(''); setVDiscount(''); setVMaxUses(''); setVExpires('');
      fetchAll();
    } catch { alert('Gagal simpan voucher'); }
  };

  const deleteVoucher = async (id: number) => {
    if (!confirm('Hapus voucher?')) return;
    await fetch('/api/vouchers', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) });
    fetchAll();
  };

  const simulateOrderPayment = async (orderId: number) => {
    await fetch('/api/simulate-payment', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ order_id: orderId })
    });
    fetchAll();
  };

  const retryDelivery = async (id: number) => {
    await fetch('/api/delivery', {
      method: 'PUT', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, status: 'delivered' })
    });
    fetchAll();
  };

  if (!user) return null;

  const tabs = [
    { key: 'stats', label: 'Statistik', icon: BarChart3 },
    { key: 'products', label: 'Produk', icon: Package },
    { key: 'orders', label: 'Orders', icon: ShoppingBag },
    { key: 'delivery', label: 'Delivery', icon: Truck },
    { key: 'vouchers', label: 'Voucher', icon: Tag },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <div className="flex items-center gap-3 mb-6">
          <Shield className="text-amber-400" size={28} />
          <div>
            <h1 className="text-3xl font-bold">Admin Dashboard</h1>
            <p className="text-gray-400 text-sm">Kelola produk, pesanan, dan delivery</p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 overflow-x-auto mb-6 pb-1">
          {tabs.map(t => (
            <button
              key={t.key}
              onClick={() => setTab(t.key as any)}
              className={`px-4 py-2.5 rounded-xl text-sm font-medium whitespace-nowrap transition flex items-center gap-1.5 ${
                tab === t.key
                  ? 'bg-emerald-500 text-gray-950'
                  : 'bg-gray-900 border border-gray-800 text-gray-400 hover:text-white'
              }`}
            >
              <t.icon size={16} /> {t.label}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : (
          <>
            {/* STATS TAB */}
            {tab === 'stats' && stats && (
              <div>
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                  {[
                    { label: 'Total Revenue', value: `Rp ${(stats.totalRevenue || 0).toLocaleString('id-ID')}`, icon: DollarSign, color: 'text-emerald-400 bg-emerald-400/10' },
                    { label: 'Total Orders', value: stats.totalOrders, icon: ShoppingBag, color: 'text-blue-400 bg-blue-400/10' },
                    { label: 'Pending Orders', value: stats.pendingOrders, icon: Clock, color: 'text-yellow-400 bg-yellow-400/10' },
                    { label: 'Delivered', value: stats.deliveredOrders, icon: CheckCircle, color: 'text-emerald-400 bg-emerald-400/10' },
                    { label: 'Today Revenue', value: `Rp ${(stats.todayRevenue || 0).toLocaleString('id-ID')}`, icon: DollarSign, color: 'text-cyan-400 bg-cyan-400/10' },
                    { label: 'Today Orders', value: stats.todayOrders, icon: ShoppingBag, color: 'text-purple-400 bg-purple-400/10' },
                    { label: 'Pending Delivery', value: stats.pendingDelivery, icon: Truck, color: 'text-orange-400 bg-orange-400/10' },
                    { label: 'Failed Delivery', value: stats.failedDelivery, icon: XCircle, color: 'text-red-400 bg-red-400/10' },
                  ].map((s, i) => (
                    <div key={i} className="bg-gray-900 border border-gray-800 rounded-xl p-4">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center mb-2 ${s.color}`}>
                        <s.icon size={16} />
                      </div>
                      <p className="text-2xl font-bold">{s.value}</p>
                      <p className="text-xs text-gray-500">{s.label}</p>
                    </div>
                  ))}
                </div>

                {/* Revenue Chart */}
                <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
                  <h3 className="font-bold mb-4">Revenue 7 Hari Terakhir</h3>
                  <div className="flex items-end gap-2 h-48">
                    {(stats.revenueByDay || []).map((d: any, i: number) => {
                      const maxRev = Math.max(...(stats.revenueByDay || []).map((r: any) => r.revenue), 1);
                      const height = Math.max((d.revenue / maxRev) * 100, 4);
                      return (
                        <div key={i} className="flex-1 flex flex-col items-center gap-1">
                          <span className="text-xs text-gray-500">{d.revenue > 0 ? `${(d.revenue / 1000).toFixed(0)}K` : '0'}</span>
                          <div className="w-full bg-emerald-500/20 rounded-t" style={{ height: `${height}%` }}>
                            <div className="w-full h-full bg-gradient-to-t from-emerald-500 to-emerald-400 rounded-t" />
                          </div>
                          <span className="text-xs text-gray-500">{new Date(d.date).toLocaleDateString('id-ID', { weekday: 'short' })}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Webhook Info */}
                <div className="mt-6 bg-gray-900 border border-gray-800 rounded-xl p-6">
                  <h3 className="font-bold mb-3 flex items-center gap-2"><Zap size={18} className="text-emerald-400" /> Webhook Endpoint</h3>
                  <div className="bg-gray-800 rounded-lg p-3 font-mono text-sm text-emerald-400 overflow-x-auto">
                    POST /api/webhook
                  </div>
                  <p className="text-xs text-gray-500 mt-2">
                    Expected payload: {`{ status: "PAID", order_id: "INV-xxx", transaction_id: "..." }`}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">
                    Supported statuses: PAID, paid, settlement, EXPIRED, expired, cancel
                  </p>
                </div>
              </div>
            )}

            {/* PRODUCTS TAB */}
            {tab === 'products' && (
              <div>
                <button
                  onClick={() => { resetProductForm(); setShowProductForm(true); }}
                  className="mb-4 px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-gray-950 font-semibold rounded-xl transition flex items-center gap-1.5"
                >
                  <Plus size={16} /> Tambah Produk
                </button>

                {showProductForm && (
                  <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 mb-6">
                    <h3 className="font-bold mb-4">{editingProduct ? 'Edit Produk' : 'Tambah Produk Baru'}</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm text-gray-400 mb-1 block">Nama</label>
                        <input value={pName} onChange={e => setPName(e.target.value)} className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-emerald-500" placeholder="VIP Rank" />
                      </div>
                      <div>
                        <label className="text-sm text-gray-400 mb-1 block">Harga (Rp)</label>
                        <input type="number" value={pPrice} onChange={e => setPPrice(e.target.value)} className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-emerald-500" placeholder="50000" />
                      </div>
                      <div>
                        <label className="text-sm text-gray-400 mb-1 block">Kategori</label>
                        <select value={pCategory} onChange={e => setPCategory(e.target.value)} className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-emerald-500">
                          <option value="rank">⚔️ Rank</option>
                          <option value="item">🎒 Item</option>
                          <option value="access">🔑 Access</option>
                          <option value="whitelist">📋 Whitelist</option>
                          <option value="balance">💰 Balance</option>
                        </select>
                      </div>
                      <div>
                        <label className="text-sm text-gray-400 mb-1 block">Stock (kosongkan = unlimited)</label>
                        <input type="number" value={pStock} onChange={e => setPStock(e.target.value)} className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-emerald-500" placeholder="100" />
                      </div>
                      <div className="sm:col-span-2">
                        <label className="text-sm text-gray-400 mb-1 block">Deskripsi</label>
                        <input value={pDesc} onChange={e => setPDesc(e.target.value)} className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-emerald-500" placeholder="Rank VIP dengan fitur lengkap" />
                      </div>
                      <div className="sm:col-span-2">
                        <label className="text-sm text-gray-400 mb-1 block">Command (gunakan {'{username}'} untuk MC username)</label>
                        <input value={pCommand} onChange={e => setPCommand(e.target.value)} className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white font-mono focus:outline-none focus:border-emerald-500" placeholder="lp user {username} parent add vip" />
                      </div>
                    </div>
                    <div className="flex gap-2 mt-4">
                      <button onClick={saveProduct} className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-gray-950 font-semibold rounded-lg transition">Simpan</button>
                      <button onClick={resetProductForm} className="px-4 py-2 bg-gray-800 hover:bg-gray-700 text-white rounded-lg transition">Batal</button>
                    </div>
                  </div>
                )}

                <div className="space-y-3">
                  {products.map(p => (
                    <div key={p.id} className="bg-gray-900 border border-gray-800 rounded-xl p-4 flex items-center gap-4">
                      <div className="w-12 h-12 bg-gray-800 rounded-lg flex items-center justify-center text-xl">
                        {{ rank: '👑', item: '💎', access: '🔐', whitelist: '✅', balance: '🪙' }[p.category as string] || '📦'}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-semibold">{p.name}</h4>
                        <p className="text-sm text-gray-400 truncate">{p.description}</p>
                        <div className="flex gap-2 mt-1">
                          <span className="text-xs px-2 py-0.5 bg-gray-800 rounded-full text-gray-400 capitalize">{p.category}</span>
                          <span className="text-xs px-2 py-0.5 bg-gray-800 rounded-full text-gray-400">Rp {(p.price || 0).toLocaleString('id-ID')}</span>
                          <span className={`text-xs px-2 py-0.5 rounded-full ${p.active ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400'}`}>{p.active ? 'Active' : 'Inactive'}</span>
                          {p.stock !== null && <span className="text-xs px-2 py-0.5 bg-gray-800 rounded-full text-gray-400">Stock: {p.stock}</span>}
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        <button onClick={() => editProduct(p)} className="p-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded-lg transition"><Edit3 size={16} /></button>
                        <button onClick={() => deleteProduct(p.id)} className="p-2 text-gray-400 hover:text-red-400 hover:bg-gray-800 rounded-lg transition"><Trash2 size={16} /></button>
                      </div>
                    </div>
                  ))}
                  {products.length === 0 && <p className="text-center text-gray-500 py-8">Belum ada produk</p>}
                </div>
              </div>
            )}

            {/* ORDERS TAB */}
            {tab === 'orders' && (
              <div className="space-y-3">
                {orders.map((o: any) => (
                  <div key={o.id} className="bg-gray-900 border border-gray-800 rounded-xl p-4">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                      <div>
                        <span className="font-mono text-sm text-gray-400">{o.invoice_number}</span>
                        <span className={`ml-2 px-2 py-0.5 rounded-full text-xs font-medium ${
                          o.status === 'pending' ? 'bg-yellow-400/10 text-yellow-400' :
                          o.status === 'paid' ? 'bg-blue-400/10 text-blue-400' :
                          o.status === 'delivered' ? 'bg-emerald-400/10 text-emerald-400' :
                          'bg-red-400/10 text-red-400'
                        }`}>{o.status}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-emerald-400 font-bold">Rp {(o.final_amount || 0).toLocaleString('id-ID')}</span>
                        {o.status === 'pending' && (
                          <button onClick={() => simulateOrderPayment(o.id)} className="px-3 py-1 bg-emerald-500/20 text-emerald-400 rounded-lg text-xs font-medium hover:bg-emerald-500/30 transition flex items-center gap-1">
                            <Zap size={12} /> Simulate Pay
                          </button>
                        )}
                      </div>
                    </div>
                    <div className="text-sm text-gray-400">
                      MC: {o.minecraft_username} • {new Date(o.created_at).toLocaleString('id-ID')}
                    </div>
                  </div>
                ))}
                {orders.length === 0 && <p className="text-center text-gray-500 py-8">Belum ada pesanan</p>}
              </div>
            )}

            {/* DELIVERY TAB */}
            {tab === 'delivery' && (
              <div className="space-y-3">
                {delivery.map((d: any) => (
                  <div key={d.id} className="bg-gray-900 border border-gray-800 rounded-xl p-4">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                            d.status === 'queued' ? 'bg-yellow-400/10 text-yellow-400' :
                            d.status === 'delivered' ? 'bg-emerald-400/10 text-emerald-400' :
                            'bg-red-400/10 text-red-400'
                          }`}>{d.status}</span>
                          <span className="text-sm text-gray-400">{d.orders?.invoice_number}</span>
                        </div>
                        <p className="font-mono text-sm text-gray-300 bg-gray-800 px-2 py-1 rounded">{d.command || 'No command'}</p>
                        <p className="text-xs text-gray-500 mt-1">
                          MC: {d.orders?.minecraft_username} • Attempts: {d.attempts || 0}
                        </p>
                      </div>
                      {d.status === 'failed' && (
                        <button onClick={() => retryDelivery(d.id)} className="px-3 py-1.5 bg-emerald-500/20 text-emerald-400 rounded-lg text-xs font-medium hover:bg-emerald-500/30 transition flex items-center gap-1">
                          <RefreshCw size={12} /> Retry
                        </button>
                      )}
                    </div>
                  </div>
                ))}
                {delivery.length === 0 && <p className="text-center text-gray-500 py-8">Belum ada delivery queue</p>}
              </div>
            )}

            {/* VOUCHERS TAB */}
            {tab === 'vouchers' && (
              <div>
                <button
                  onClick={() => setShowVoucherForm(true)}
                  className="mb-4 px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-gray-950 font-semibold rounded-xl transition flex items-center gap-1.5"
                >
                  <Plus size={16} /> Tambah Voucher
                </button>

                {showVoucherForm && (
                  <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 mb-6">
                    <h3 className="font-bold mb-4">Buat Voucher Baru</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm text-gray-400 mb-1 block">Kode</label>
                        <input value={vCode} onChange={e => setVCode(e.target.value.toUpperCase())} className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-emerald-500" placeholder="DISKON50" />
                      </div>
                      <div>
                        <label className="text-sm text-gray-400 mb-1 block">Diskon (%)</label>
                        <input type="number" value={vDiscount} onChange={e => setVDiscount(e.target.value)} className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-emerald-500" placeholder="50" />
                      </div>
                      <div>
                        <label className="text-sm text-gray-400 mb-1 block">Max Pemakaian</label>
                        <input type="number" value={vMaxUses} onChange={e => setVMaxUses(e.target.value)} className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-emerald-500" placeholder="100" />
                      </div>
                      <div>
                        <label className="text-sm text-gray-400 mb-1 block">Expired</label>
                        <input type="datetime-local" value={vExpires} onChange={e => setVExpires(e.target.value)} className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-emerald-500" />
                      </div>
                    </div>
                    <div className="flex gap-2 mt-4">
                      <button onClick={saveVoucher} className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-gray-950 font-semibold rounded-lg transition">Simpan</button>
                      <button onClick={() => setShowVoucherForm(false)} className="px-4 py-2 bg-gray-800 hover:bg-gray-700 text-white rounded-lg transition">Batal</button>
                    </div>
                  </div>
                )}

                <div className="space-y-3">
                  {vouchers.map(v => (
                    <div key={v.id} className="bg-gray-900 border border-gray-800 rounded-xl p-4 flex items-center justify-between">
                      <div>
                        <span className="font-mono font-bold text-emerald-400">{v.code}</span>
                        <div className="flex gap-2 mt-1">
                          <span className="text-xs px-2 py-0.5 bg-gray-800 rounded-full text-gray-400">{v.discount_percent}% off</span>
                          <span className="text-xs px-2 py-0.5 bg-gray-800 rounded-full text-gray-400">{v.used_count}/{v.max_uses} used</span>
                          <span className={`text-xs px-2 py-0.5 rounded-full ${v.active ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400'}`}>{v.active ? 'Active' : 'Inactive'}</span>
                        </div>
                      </div>
                      <button onClick={() => deleteVoucher(v.id)} className="p-2 text-gray-400 hover:text-red-400 transition"><Trash2 size={16} /></button>
                    </div>
                  ))}
                  {vouchers.length === 0 && <p className="text-center text-gray-500 py-8">Belum ada voucher</p>}
                </div>
              </div>
            )}
          </>
        )}
      </motion.div>
    </div>
  );
}
