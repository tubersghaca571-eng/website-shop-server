import { useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AuthContext, CartContext } from '../App';
import { ShoppingCart, User, LogOut, Shield, Package, Home as HomeIcon, Store } from 'lucide-react';
import supabase from '../lib/supabase';

export default function Navbar() {
  const { user } = useContext(AuthContext);
  const { cart } = useContext(CartContext);
  const navigate = useNavigate();
  const cartCount = cart.reduce((s: number, c: any) => s + c.qty, 0);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate('/');
  };

  return (
    <nav className="sticky top-0 z-50 bg-gray-900/95 backdrop-blur-md border-b border-gray-800">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 group">
          <div className="w-9 h-9 bg-emerald-500 rounded-lg flex items-center justify-center font-bold text-gray-950 text-sm group-hover:bg-emerald-400 transition-colors">MC</div>
          <span className="font-bold text-lg hidden sm:block">MC<span className="text-emerald-400">Shop</span></span>
        </Link>

        <div className="flex items-center gap-1 sm:gap-2">
          <Link to="/" className="px-3 py-2 rounded-lg text-sm text-gray-400 hover:text-white hover:bg-gray-800 transition flex items-center gap-1.5">
            <HomeIcon size={16} /> <span className="hidden sm:inline">Home</span>
          </Link>
          <Link to="/shop" className="px-3 py-2 rounded-lg text-sm text-gray-400 hover:text-white hover:bg-gray-800 transition flex items-center gap-1.5">
            <Store size={16} /> <span className="hidden sm:inline">Shop</span>
          </Link>
          {user && (
            <>
              <Link to="/orders" className="px-3 py-2 rounded-lg text-sm text-gray-400 hover:text-white hover:bg-gray-800 transition flex items-center gap-1.5">
                <Package size={16} /> <span className="hidden sm:inline">Orders</span>
              </Link>
              <Link to="/admin" className="px-3 py-2 rounded-lg text-sm text-amber-400 hover:text-amber-300 hover:bg-gray-800 transition flex items-center gap-1.5">
                <Shield size={16} /> <span className="hidden sm:inline">Admin</span>
              </Link>
            </>
          )}
        </div>

        <div className="flex items-center gap-2">
          <Link to="/cart" className="relative p-2 rounded-lg text-gray-400 hover:text-white hover:bg-gray-800 transition">
            <ShoppingCart size={20} />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-emerald-500 text-gray-950 text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">{cartCount}</span>
            )}
          </Link>
          {user ? (
            <div className="flex items-center gap-2">
              <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-gray-800 rounded-lg">
                <User size={14} className="text-emerald-400" />
                <span className="text-sm text-gray-300 max-w-[120px] truncate">{user.email}</span>
              </div>
              <button onClick={handleLogout} className="p-2 rounded-lg text-gray-400 hover:text-red-400 hover:bg-gray-800 transition">
                <LogOut size={18} />
              </button>
            </div>
          ) : (
            <Link to="/login" className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-gray-950 font-semibold rounded-lg text-sm transition flex items-center gap-1.5">
              <User size={16} /> Login
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
}
