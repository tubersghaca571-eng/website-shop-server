import { useContext } from 'react';
import { CartContext } from '../App';
import { motion } from 'framer-motion';
import { ShoppingCart, Star, Zap } from 'lucide-react';

const categoryColors: Record<string, string> = {
  rank: 'from-amber-500 to-orange-600',
  item: 'from-blue-500 to-cyan-600',
  access: 'from-purple-500 to-pink-600',
  whitelist: 'from-emerald-500 to-teal-600',
  balance: 'from-yellow-500 to-amber-600',
};

const categoryLabels: Record<string, string> = {
  rank: '⚔️ Rank',
  item: '🎒 Item',
  access: '🔑 Access',
  whitelist: '📋 Whitelist',
  balance: '💰 Balance',
};

const categoryIcons: Record<string, string> = {
  rank: '👑',
  item: '💎',
  access: '🔐',
  whitelist: '✅',
  balance: '🪙',
};

export default function ProductCard({ product }: { product: any }) {
  const { addToCart } = useContext(CartContext);

  const gradient = categoryColors[product.category] || 'from-gray-500 to-gray-600';
  const label = categoryLabels[product.category] || product.category;
  const icon = categoryIcons[product.category] || '📦';

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      className="bg-gray-900 border border-gray-800 rounded-2xl overflow-hidden group hover:border-emerald-500/50 transition-all duration-300"
    >
      <div className={`h-32 bg-gradient-to-br ${gradient} flex items-center justify-center relative overflow-hidden`}>
        <div className="absolute inset-0 bg-black/20" />
        <span className="text-5xl relative z-10 group-hover:scale-110 transition-transform duration-300">{icon}</span>
        <div className="absolute top-3 right-3 bg-black/40 backdrop-blur-sm px-2.5 py-1 rounded-full">
          <span className="text-xs font-medium text-white/90">{label}</span>
        </div>
        {product.stock !== null && product.stock <= 5 && product.stock > 0 && (
          <div className="absolute top-3 left-3 bg-red-500/80 backdrop-blur-sm px-2.5 py-1 rounded-full flex items-center gap-1">
            <Zap size={10} />
            <span className="text-xs font-bold">{product.stock} left!</span>
          </div>
        )}
      </div>
      <div className="p-4">
        <h3 className="font-bold text-lg text-white mb-1">{product.name}</h3>
        <p className="text-gray-400 text-sm mb-3 line-clamp-2">{product.description}</p>
        <div className="flex items-center justify-between">
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-bold text-emerald-400">Rp {(product.price || 0).toLocaleString('id-ID')}</span>
          </div>
          <button
            onClick={() => addToCart(product)}
            disabled={product.stock === 0}
            className="p-2.5 bg-emerald-500 hover:bg-emerald-400 text-gray-950 rounded-xl transition disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <ShoppingCart size={18} />
          </button>
        </div>
      </div>
    </motion.div>
  );
}
